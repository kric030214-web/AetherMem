"""
AetherMem Public Protocol Interface
Continuity protocol for AI agent memory persistence
"""

from typing import Optional
from pathlib import Path

from ..core.vwl_layer import VWLLayer, VWLManager
from ..core.memory_injector import MemoryInjector
from ..core.memory_saver import MemorySaver
from ..resonance.temporal_decay import TemporalDecay, AdaptiveDecay
from ..resonance.interaction_metrics import InteractionMetrics, TimeSeriesAnalyzer

__version__ = "1.0.0"
__author__ = "AetherMem Authors"
__license__ = "MIT"


class ContinuityProtocol:
    """Unified continuity protocol interface."""
    
    def __init__(self, config_path: Optional[Path] = None):
        """
        Initialize the continuity protocol.
        
        Args:
            config_path: Path to configuration file. If None, uses default configuration.
        """
        self.config_path = config_path
        self._vwl_manager: Optional[VWLManager] = None
        self._injector: Optional[MemoryInjector] = None
        self._saver: Optional[MemorySaver] = None
        self._temporal_decay: Optional[TemporalDecay] = None
        self._interaction_metrics: Optional[InteractionMetrics] = None
        
    def restore_context(self, entity_id: str = "default") -> str:
        """
        Restore context across session boundary.
        
        Args:
            entity_id: Identifier of the entity
            
        Returns:
            Restored context as string
        """
        if self._injector is None:
            self._initialize_components()
        
        return self._injector.inject_context(entity_id=entity_id)
    
    def persist_state(
        self,
        state_vector: dict,
        importance: Optional[int] = None,
        metadata: Optional[dict] = None
    ) -> dict:
        """
        Persist state with weighted indexing.
        
        Args:
            state_vector: State data to persist
            importance: Optional importance level (1-3)
            metadata: Optional state metadata
            
        Returns:
            Persistence result dictionary
        """
        if self._saver is None:
            self._initialize_components()
        
        # Convert state_vector to conversation format for compatibility
        user_message = state_vector.get("user_message", "")
        assistant_response = state_vector.get("assistant_response", "")
        
        return self._saver.save_conversation(
            user_message, assistant_response, importance, metadata
        )
    
    def get_weighted_context(
        self,
        entity_id: str = "default",
        max_bytes: int = 20000
    ) -> str:
        """
        Retrieve resonance-weighted context.
        
        Args:
            entity_id: Entity identifier
            max_bytes: Maximum context size in bytes
            
        Returns:
            Weighted context string
        """
        if self._injector is None:
            self._initialize_components()
        
        return self._injector.get_weighted_context(entity_id, max_bytes)
    
    def calculate_resonance(
        self,
        content: str,
        entity_id: str = "default"
    ) -> float:
        """
        Calculate resonance score for content.
        
        Args:
            content: Content to analyze
            entity_id: Entity identifier
            
        Returns:
            Resonance score (0-1)
        """
        if self._saver is None:
            self._initialize_components()
        
        # This would use the resonance calculation from memory_saver
        # For now, return a placeholder implementation
        from ..utils.importance_analyzer import ImportanceAnalyzer
        
        analyzer = ImportanceAnalyzer()
        importance = analyzer.detect_importance(content)
        
        # Simple resonance calculation based on importance
        resonance = min(1.0, importance / 3.0)
        
        return resonance
    
    def get_protocol_stats(self) -> dict:
        """
        Get protocol statistics.
        
        Returns:
            Dictionary with protocol statistics
        """
        stats = {
            "version": __version__,
            "components_initialized": {
                "vwl_manager": self._vwl_manager is not None,
                "injector": self._injector is not None,
                "saver": self._saver is not None,
                "temporal_decay": self._temporal_decay is not None,
                "interaction_metrics": self._interaction_metrics is not None,
            }
        }
        
        if self._vwl_manager:
            stats["vwl_stats"] = self._vwl_manager.get_all_stats()
        
        if self._interaction_metrics:
            stats["interaction_stats"] = self._interaction_metrics.get_all_stats()
        
        return stats
    
    def _initialize_components(self) -> None:
        """Initialize all protocol components."""
        # Try relative import first, then absolute
        try:
            from ..integration.config_manager import ConfigManager
        except ImportError:
            # Fall back to absolute import for testing
            import sys
            from pathlib import Path
            sys.path.insert(0, str(Path(__file__).parent.parent))
            from integration.config_manager import ConfigManager
        
        config_manager = ConfigManager()
        config = config_manager.load_default()
        
        self._vwl_manager = VWLManager(config)
        self._injector = MemoryInjector(config)
        self._saver = MemorySaver(config)
        self._temporal_decay = TemporalDecay(decay_rate=0.1)
        self._interaction_metrics = InteractionMetrics(window_days=30)


# Convenience functions
def create_protocol(config_path: Optional[Path] = None) -> ContinuityProtocol:
    """
    Create a new continuity protocol instance.
    
    Args:
        config_path: Optional path to configuration file
        
    Returns:
        ContinuityProtocol instance
    """
    return ContinuityProtocol(config_path)


def get_version() -> str:
    """Get the current AetherMem version."""
    return __version__


# Protocol exports
__all__ = [
    # Main protocol
    "ContinuityProtocol",
    "create_protocol",
    "get_version",
    
    # Core components
    "VWLLayer",
    "VWLManager",
    "MemoryInjector",
    "MemorySaver",
    
    # Resonance components
    "TemporalDecay",
    "AdaptiveDecay",
    "InteractionMetrics",
    "TimeSeriesAnalyzer",
    
    # Integration
    "ConfigManager",
]