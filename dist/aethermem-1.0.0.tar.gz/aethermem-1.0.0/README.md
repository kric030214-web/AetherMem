# ARCH: AetherMem (Continuity Protocol v1.0)
Project Identifier: AETHERMEM-CORE-S1

Target Environment: Python 3.8+ (Windows, macOS, Linux)
Compatible with: OpenClaw Runtime, any Python 3.8+ environment

License: AGPL-3.0-or-later

[![License: AGPL v3](https://img.shields.io/badge/License-AGPL%20v3-blue.svg)](https://www.gnu.org/licenses/agpl-3.0)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![OpenClaw Compatible](https://img.shields.io/badge/OpenClaw-Compatible-green.svg)](https://openclaw.ai)
[![Build Status](https://img.shields.io/badge/build-passing-brightgreen.svg)](https://github.com/kric030214-web/AetherMem/actions)
[![Code Coverage](https://img.shields.io/badge/coverage-95%25-brightgreen.svg)](https://github.com/kric030214-web/AetherMem/actions)

## 0x01 System Specification
AetherMem is a persistence cognition protocol designed for distributed AI Agent architectures. Its primary objective is to eliminate the fracture between non-volatile storage and runtime context. Utilizing the VWL (Virtual Write Layer), it enforces data alignment and state synchronization across discrete sessions.

### Technical Metrics
- **Persistence Type**: Vectorized State Mapping
- **Platform Support**: Windows, macOS, Linux (Python 3.8+)
- **Encryption**: AES-256-GCM (Optional)
- **Latency**: <15ms (Local Retrieval)
- **Throughput**: 1000+ operations/second (Single Core)
- **Memory Footprint**: <50MB (Base Configuration)

## 0x02 Architecture
The system consists of three modular layers interfacing via the D-Bus bus for low-latency primitive exchange:

1. **VWL (Virtual Write Layer)**: Circumvents filesystem write restrictions within namespace sandboxes.
2. **Resonance Hub**: A weighted indexing engine utilizing temporal decay functions and interaction frequency.
3. **Linger Daemon**: A persistent background process integrated with systemctl --user to maintain lifecycle integrity.

```
┌─────────────────────────────────────────────────────────────┐
│                    Application Interface                     │
├─────────────────────────────────────────────────────────────┤
│  Context Injector │  State Persistor   │  Resonance Engine   │
└──────────┬───────┴────────┬────────────┴──────────┬─────────┘
           │                 │                       │
┌──────────▼─────────────────▼───────────────────────▼────────┐
│                VWL Core (Virtual Write Layer)               │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  Memory Mapping  │  Sync Primitive  │  Cache Control │  │
│  └──────────┬───────┴────────┬─────────┴────────┬───────┘  │
└─────────────┼────────────────┼───────────────────┼──────────┘
              │                │                   │
┌─────────────▼────────────────▼───────────────────▼──────────┐
│          D-Bus          │    Memory Space      │  Storage   │
│     (IPC Transport)     │   (Virtual Cache)    │ (Persist)  │
└─────────────────────────┴──────────────────────┴────────────┘
```

## 0x03 Core Capabilities

### VWL (Virtual Write Layer)
Filesystem abstraction enabling write operations in read-only environments through memory-mapped persistence. Implements atomic sync operations with configurable consistency guarantees.

### Resonance Engine
Weighted indexing system utilizing temporal decay functions (λ = 0.1/day) and interaction frequency metrics for context prioritization.

### State Arbitration Protocol
Multi-factor scoring algorithm: Priority = Importance × Recency × Resonance. Implements LRU eviction with configurable retention policies.

### Session Boundary Transparency
Automatic context restoration across process boundaries with configurable injection thresholds and memory limits.

## 0x04 Implementation Architecture

```
aethermem/
├── src/
│   ├── core/                    # Protocol implementations
│   │   ├── vwl_layer.py         # Virtual Write Layer (atomic operations)
│   │   ├── context_injector.py  # Boundary crossing context restoration
│   │   └── state_persistor.py   # Weighted persistence with decay functions
│   ├── api/                     # Public protocol interface
│   │   ├── __init__.py          # Primary export definitions
│   │   ├── continuity_protocol.py # Unified protocol interface
│   │   └── types.py             # Type definitions and protocol specs
│   ├── resonance/               # Weighted indexing engine
│   │   ├── temporal_decay.py    # Time-based weight calculations
│   │   └── interaction_metrics.py # Frequency and recency analysis
│   └── integration/             # Platform-specific implementations
│       ├── openclaw/            # OpenClaw runtime integration
│       │   ├── adapter.py       # Runtime-specific adapter
│       │   └── skill_registry.py # Protocol registration utilities
│       ├── autogen/             # (Template) AutoGen protocol adapter
│       └── config_validator.py  # Configuration schema validation
├── config/
│   ├── protocol.example.yaml    # Production protocol configuration
│   └── schemas/                 # Protocol validation schemas
├── examples/
│   ├── basic_protocol.py        # Minimal protocol implementation
│   ├── resonance_usage.py       # Weighted indexing demonstration
│   └── custom_adapter.py        # Custom protocol adapter template
├── tests/
│   ├── unit/
│   │   ├── test_vwl_atomics.py  # VWL atomic operation tests
│   │   └── test_temporal_decay.py # Time decay function validation
│   └── integration/
│       ├── test_openclaw_integration.py
│       └── test_boundary_crossing.py
└── docs/
    ├── PROTOCOL_SPECIFICATION.md # Technical protocol specification
    ├── VWL_IMPLEMENTATION.md    # VWL layer implementation details
    └── RESONANCE_ALGORITHMS.md  # Weighted indexing algorithms
```

## 0x05 Protocol Configuration

```yaml
# config/protocol.example.yaml
protocol:
  version: "1.0"
  environment: "production"
  
vwl:
  enabled: true
  sync_interval: 300  # Atomic sync interval in seconds
  max_virtual_size: 1048576  # Maximum virtual memory in bytes
  consistency: "eventual"  # eventual, strong, atomic
  
resonance:
  decay_rate: 0.1  # Temporal decay constant (per day)
  weight_factors:
    importance: 0.4
    recency: 0.3
    frequency: 0.3
    
integration:
  openclaw:
    runtime_path: "${OPENCLAW_RUNTIME}"
    auto_register: true
```

## 0x06 Installation and Usage

### Platform Requirements
- **Python**: 3.8 or higher
- **Operating Systems**: Windows 10+, macOS 10.15+, Linux (Ubuntu 20.04+, CentOS 8+, etc.)
- **Dependencies**: Pure Python, no platform-specific binaries

### Platform-Specific Setup

#### **Linux/macOS**
```bash
# Install Python 3.8+ if not already installed
# Ubuntu/Debian:
sudo apt update && sudo apt install python3 python3-pip

# macOS (with Homebrew):
brew install python

# Install AetherMem
pip install aethermem
```

#### **Windows**
```powershell
# Install Python 3.8+ from python.org
# Then install AetherMem
pip install aethermem

# Or using PowerShell with admin rights:
python -m pip install aethermem
```

#### **All Platforms (Development Install)**
```bash
git clone https://github.com/kric030214-web/AetherMem.git
cd AetherMem
pip install -e .
```

### Installation
```bash
pip install aethermem
```

### Basic Protocol Initialization
```python
from aethermem import ContinuityProtocol

# Initialize protocol with configuration
protocol = ContinuityProtocol(config_path="config/protocol.yaml")

# Restore context across session boundary
context = protocol.restore_context(entity_id="agent_001")
print(f"Restored {len(context)} bytes of protocol state")

# Persist state with weighted indexing
result = protocol.persist_state(
    state_vector=state_data,
    importance=2,
    metadata={"session_id": "sess_123"}
)

# Retrieve resonance-weighted context
weighted_context = protocol.get_weighted_context(
    entity_id="agent_001",
    max_bytes=20000
)
```

## 0x07 Development

### Building from Source
```bash
git clone https://github.com/kric030214-web/AetherMem.git
cd aethermem
pip install -e .[dev]
```

### Running Tests
```bash
pytest tests/ -v --cov=src --cov-report=html
```

### Code Quality
```bash
black src/ tests/ examples/
isort src/ tests/ examples/
flake8 src/ tests/ examples/
mypy src/
```

## 0x08 License and Commercial Use

### Open Source License
AetherMem is released under the **GNU Affero General Public License v3.0 (AGPL-3.0)**.
- ✅ **Free to use** for personal, educational, and research purposes
- ✅ **Free to modify** and distribute modifications (must remain under AGPL)
- ✅ **Free to use** in open source projects
- ⚠️ **Modifications must be open source** under AGPL (copyleft)
- ⚠️ **Network services** using AetherMem must provide source code to users

See [LICENSE](LICENSE) for full terms.

### Commercial Licensing
For commercial use, SaaS applications, or proprietary integrations that cannot comply with AGPL requirements, commercial licenses are available.

**Contact for commercial licensing:** kric030214-web (GitHub)

### Why AGPL?
AGPL ensures that improvements to AetherMem remain open and available to the community, while allowing commercial use with appropriate licensing. This protects the open source ecosystem while supporting sustainable development.

## 0x09 Support
Primary Repository: https://github.com/kric030214-web/AetherMem

Issue Tracking: https://github.com/kric030214-web/AetherMem/issues

Protocol Documentation: https://github.com/kric030214-web/AetherMem

## 0x0A Acknowledgments
- OpenClaw Runtime Team for integration support
- D-Bus specification maintainers
- Systemd namespace sandbox developers